	component nios_td3 is
		port (
			clk_clk       : in  std_logic                    := 'X'; -- clk
			reset_reset_n : in  std_logic                    := 'X'; -- reset_n
			pio_0_export  : out std_logic_vector(7 downto 0)         -- export
		);
	end component nios_td3;

	u0 : component nios_td3
		port map (
			clk_clk       => CONNECTED_TO_clk_clk,       --   clk.clk
			reset_reset_n => CONNECTED_TO_reset_reset_n, -- reset.reset_n
			pio_0_export  => CONNECTED_TO_pio_0_export   -- pio_0.export
		);

